// Assigment1.cpp : This file contains the 'main' function. Program execution begins and ends there.
//Razan Alsaddi 991505589

#include <iostream>
#include <sdl.h>
#include<cstdlib>
#include<ctime>
#include <string>
#include<SDL_ttf.h>//required for draw font
 
using namespace std;
#define WINDOW_WIDTH 800
#define WINDOW_HIEGH 600

SDL_Renderer* renderer;
SDL_Event event;
SDL_Window* window;

SDL_Rect playerPadderl;
SDL_Rect aiPaddel;
SDL_Rect ball;
SDL_Rect divider;
SDL_Rect backgroung = { 0,0,WINDOW_WIDTH,WINDOW_HIEGH };

TTF_Font* font;
SDL_Texture* fontTexture;

SDL_Rect fontRectScore;// thid define the position of our 'score' text on the screen
void RenderFont(const char* text, int x, int y, bool isRefreshedText);

bool isRunning = true;
bool isOver = false;
int mouseX , mouseY; //for mouse cord
int playerScore, aiScore;

int speed_x, speed_y; //store the speed of x and y
int aiSpeed ;
int direction[2] = {-1,1}; // array to store two directions

bool CheckCollision(SDL_Rect a, SDL_Rect b);
bool InitGameEngine();
void InitGameWorld();
void Inpute();
void Update();
void Render();
void Quite();



int main(int argc,char * agv[])
{
	int b;
	if (!InitGameEngine()) return -1;
	InitGameWorld();

	//Setup the Game Loop
	while (isRunning)
	{
		Inpute();
		Update();
		Render();

	}
	while (isOver)
	{
		Inpute();
	}
	
	
	Quite();
}

bool InitGameEngine()
{
	//initialize the spped variables 
	speed_x = -1;
	speed_y = -1;
	aiSpeed = 0;
	playerScore = 0;
	aiScore = 0;

	 window = SDL_CreateWindow("First SDL App", SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED, WINDOW_WIDTH, WINDOW_HIEGH, 0);
	if (!window)
	{
		cout << "Window Initilaization failed.\n";
		return false;
	}

	renderer = SDL_CreateRenderer(window, -1, 0);
	if(!renderer)
	{
		cout << "renderer init failed.\n";
	}

	//checked is ttf engine can be used 
	if (TTF_Init() != 0)
	{
		cout << "TTF Font init failed. \n";
	}

	return true;

}
void InitGameWorld()
{
	font = TTF_OpenFont("Assets/Fonts/LTYPE.TTF",30); //30 is the size of the font

	playerPadderl.x = 20;
	playerPadderl.y = WINDOW_HIEGH*0.5-50;
	playerPadderl.w = 20;
	playerPadderl.h = 100;

	aiPaddel.x = WINDOW_WIDTH-40;
	aiPaddel.y= WINDOW_HIEGH * 0.5 - 50;
	aiPaddel.h = 100;
	aiPaddel.w = 20;


	srand(time(0));
	ball.x = (WINDOW_WIDTH * 0.5) - 30; //around 370 pixels if window is 800 in width
	ball.y = (WINDOW_HIEGH * 0.5) - 10; //around the center, at about 290 pixels
	
	speed_x = (rand() % 2 + 1) * direction[rand() % 2];
	speed_y = (rand() % 2 + 1) * direction[rand() % 2];
	
	ball.w = 20;
	ball.h = 20;

	divider.x = WINDOW_WIDTH * 0.5;
	divider.y = 0;
	divider.h = WINDOW_HIEGH;
	divider.w = 1;
}

void RenderFont(const char* text , int x,int y,bool isRefreshedText)
{
	if (isRefreshedText)
	{
		SDL_Color textColor = { 255,255,255,0 };
		SDL_Surface* fontSurface = TTF_RenderText_Solid(font, text, textColor);
		SDL_DestroyTexture(fontTexture);

		fontTexture = SDL_CreateTextureFromSurface(renderer, fontSurface);
		fontRectScore = { x,y,fontSurface->w,fontSurface->h };
	}
	else {
		
		SDL_Color textColor = { 255,255,255,0 };
		SDL_Surface* fontSurface = TTF_RenderText_Solid(font, text, textColor);
		fontTexture = SDL_CreateTextureFromSurface(renderer, fontSurface);
		fontRectScore = { x,y,fontSurface->w,fontSurface->h };
	}
	//draw the font
	SDL_RenderCopy(renderer,fontTexture,0,&fontRectScore);

}

void Render()
{
	SDL_SetRenderDrawColor(renderer, 5, 30, 67, 255);
	SDL_RenderFillRect(renderer, &backgroung);
	if (aiScore == 4 || playerScore == 4)
	{
		string s4;
		string s5;
		string s3 = "Game is over Player ";
		if(aiScore== 4)
		{
			s4 = "AI is the winner";
		}
		else
		{
			s4 = "Player is the winner";
		}
		s5 = "Player Score is: "  + to_string(playerScore) + "&  AI Score: " + to_string(aiScore); ;
		SDL_RenderClear(renderer);	
		RenderFont(s3.c_str(), 30, (WINDOW_HIEGH / 2)-100, false);
		RenderFont(s4.c_str(), 30, (WINDOW_HIEGH / 2) - 150, false);
		RenderFont(s5.c_str(), 30, (WINDOW_HIEGH / 2) - 200, false);
		SDL_RenderPresent(renderer);

	}
	else
	{
		SDL_RenderClear(renderer);

		//draw the current frame
		//draw the background
		

		SDL_SetRenderDrawColor(renderer, 255, 255, 255, 255);
		SDL_RenderFillRect(renderer, &playerPadderl);
		SDL_RenderFillRect(renderer, &aiPaddel);

		SDL_SetRenderDrawColor(renderer, 255, 0, 0, 255);
		SDL_RenderFillRect(renderer, &ball);

		//SDL_RenderPresent(renderer);

		SDL_SetRenderDrawColor(renderer, 0xFF, 0xFF, 0xFF, 0xFF);
		SDL_RenderFillRect(renderer, &divider);


		string s = "Score: " + to_string(playerScore);
		string s2 = "Score: " + to_string(aiScore);
		RenderFont(s.c_str(), 30, 50, true);
		RenderFont(s2.c_str(), (WINDOW_WIDTH - 200), 50, true);
		SDL_RenderPresent(renderer);
	}

	

}



void Quite()

{
	SDL_DestroyRenderer(renderer);
	SDL_DestroyWindow(window);
	SDL_Quit();
	TTF_CloseFont(font);
	TTF_Quit();
	
}

void Inpute()
{
	while (SDL_PollEvent(&event))
	{
		if (event.type == SDL_MOUSEMOTION)
		{
			SDL_GetMouseState(&mouseX, &mouseY);

		}
		if (event.type == SDL_QUIT)
		{
			isRunning = false;
			isOver = false;
		}
		if (event.type == SDL_KEYDOWN)
		{
			switch (event.key.keysym.sym)
			{
			case SDLK_ESCAPE:
					isRunning = false;
					isOver = false;
                    break;

			}
		}
	}
}

void Update()
{
	if (playerScore == 4 || aiScore == 4)
	{
		cout << "Game is over\n";
		if (playerScore==4)
		{
			cout << "Playe is the winner \n";
		}
		else
		{
			cout << "AI is the winner\n";
		}
		cout << "Playe score is " + to_string(playerScore);
		cout << "AI score is " + to_string(aiScore);
		isRunning = false;
		isOver = true;

	}
	else
	{
		playerPadderl.y = mouseY;
		if (playerPadderl.y < 0)
		{
			playerPadderl.y = 0;
		}
		else if (playerPadderl.y > (WINDOW_HIEGH - playerPadderl.h))
		{
			playerPadderl.y = WINDOW_HIEGH - playerPadderl.h;
		}
		//Our initial demo ball movmnet
		ball.x += speed_x;
		ball.y += speed_y;
		SDL_Delay(8);

		if (ball.x<0 || ball.x> WINDOW_WIDTH)
		{
			if (ball.x < 0)
			{
				aiScore = aiScore + 1;
				cout << "Ai Score" << aiScore << "\n";
			}
			else if (ball.x > WINDOW_WIDTH)
			{
				playerScore = playerScore + 1;
				cout << "Player Score" << playerScore << "\n";
			}
			ball.x = WINDOW_HIEGH / 2;
			ball.y = WINDOW_HIEGH / 2;

			speed_x = (rand() % 2 + 1) * direction[rand() % 2];
			speed_y = (rand() % 2 + 1) * direction[rand() % 2];



		}

		if (ball.y < 0 || ball.y>(WINDOW_HIEGH - ball.h))
		{
			speed_y = -speed_y;
		}

		//aiPaddel.y = ball.y - aiPaddel.h / 2 + ball.h / 2;

		//Improve AI paddel

		if (aiPaddel.y < 0)
		{
			aiPaddel.y = 0;
		}
		else if (aiPaddel.y > (WINDOW_HIEGH - aiPaddel.h))
		{
			aiPaddel.y = WINDOW_HIEGH - aiPaddel.h;
		}


		if ((ball.y > aiPaddel.y + aiPaddel.h / 2 +rand()%20+30)&&((rand() % 3 + 1) == 1))
		{

			aiSpeed =rand()%4+1;
		}
		else if ((ball.y < aiPaddel.y + aiPaddel.h / 2 )&&((rand()%3+1)==1))
		{
			aiSpeed = -1;
		}
	
		aiPaddel.y += aiSpeed;
		/*if (aiPaddel.y < 0)
		{
			aiPaddel.y = 0;
		}
		else if (aiPaddel.y > (WINDOW_HIEGH - aiPaddel.h))
		{
			aiPaddel.y = WINDOW_HIEGH - aiPaddel.h;
		}*/


		if (CheckCollision(ball, aiPaddel) || CheckCollision(ball, playerPadderl))
		{
			speed_x = -speed_x;
		}

		

	}



}

bool CheckCollision(SDL_Rect a, SDL_Rect b)
{
	//sides of the rectangles 
	int leftA, leftB;
	int rightA, rightB;
	int topA, topB;
	int bottomA, bottomB;

	//Calculate the dides if rec A
	leftA = a.x;
	rightA = a.x + a.w;
	topA = a.y;
	bottomA = a.y + a.h;

	//caluculate the sides of the rect B
	leftB = b.x;
	rightB = b.x + b.w;
	topB = b.y;
	bottomB = b.y + b.h;

	if (bottomA <= topB)
		return false;
	if (topA >= bottomB)
		return false;
	if (rightA <= leftB)
		return false;
	if (leftA >= rightB)
		return false;
	return true;

}