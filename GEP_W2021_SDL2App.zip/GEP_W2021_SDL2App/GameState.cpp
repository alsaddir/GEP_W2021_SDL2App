#include"GameState.h"
#include"GameEngine.h"
#include <ctime>






void GameState::Render()
{
	SDL_RenderClear(GameEngine::Instance()->GetRenderer()); //clear previously drawn frame

	bg->Render();
	if (player) player->Render();
	for (int i = 0; i < asteroids.size(); i++)
	{
		asteroids[i]->Render();
	}
	string s = "Score" + to_string(score);
	RenderFont(s.c_str(), 32, 50, true);
	ScreenState::Render();
}

void GameState::Enter()
{
	bgSpriteTex = GameEngine::Instance()->LoadTexture("Assets/Sprites/background.png");
	mainSpriteTex = GameEngine::Instance()->LoadTexture("Assets/Sprites/Sprites.png");


	SDL_Rect bgSrcRect = { 0,0,0,0 };
	//load the sound
	fireSound = Mix_LoadWAV("Assets/Aud/Fire.wav");
	engineSound = Mix_LoadWAV("Assets/Aud/Engines.wav");

	//load the font
	m_pFont = TTF_OpenFont("Assets/Fonts/LTYPE.TTF", 30);//30 is the initial font size

	//to set the volum of each chunk
	Mix_VolumeChunk(fireSound, 70);
	Mix_VolumeChunk(engineSound, 50);

	//to give us width/heigh ogf the texture
	SDL_QueryTexture(bgSpriteTex, NULL, NULL, &bgSrcRect.w, &bgSrcRect.h);

	SDL_Rect bgDestRect = { 0,0,0,0 };
	// we get the window dimension using SDL_GetWindowSize()
	SDL_GetWindowSize(GameEngine::Instance()->GetWindow(), &bgDestRect.w, &bgDestRect.h);

	bg = new SpriteEx(bgSpriteTex, bgSrcRect, bgDestRect);

	srand(time(0));

	/* *************** Astroids ***************** */
	SDL_Rect asteroidSrcRect = { 124,0,66,66 };// 64x64 is the width/high of asteroid
	SDL_Rect asteroidDesRect = { 0,0,64,64 };// 64x64 is the width/high of asteroid

	//generate astroides , for now we want 5
	for (int i = 0; i < 5; i++)
	{
		//generated random speed 
		float r = (1 - rand() % 2 * 2) * (rand() % 6 + 1);

		asteroidDesRect.x = (rand() % 700) + 1; // genetare between 1 & 700 pixels
		asteroidDesRect.y = (rand() % 500) + 1; // generate between 1 and 600 pixel

		Asteroid* ast = new Asteroid(mainSpriteTex, asteroidSrcRect, asteroidDesRect, r);
		asteroids.push_back(ast);//push it into the vector


	}
	player = new Player(mainSpriteTex, bgDestRect.w * 0.5, bgDestRect.h - 100);

}

void GameState::CheckCollision()
{
	//check for the player and asteroid collision
	for (int i = 0; i < (int)asteroids.size(); i++)
	{
		if (CircleCollisionTest(player->GetX(), player->GetY(),
			asteroids[i]->GetX(), asteroids[i]->GetY(),
			player->GetRadius(), asteroids[i]->GetRadius()
		))
		{

			//there was a player-asteroid collision!!!
			cout << "Player collided with an asteroid and got killed!!\n";
			//we can delete the player...
			delete player;
			player = nullptr;
			//isRunning = false;
			return;
		}

	}

	bool isBreakOutOfLoop = false;
	//check for bullet and asteroid collision
	for (int b = 0; b < (int)player->GetBullets().size(); b++)
	{

		for (int i = 0; i < (int)asteroids.size(); i++)
		{

			Bullet* bullet = player->GetBullets()[b];

			if (CircleCollisionTest(bullet->GetX(), bullet->GetY(),
				asteroids[i]->GetX(), asteroids[i]->GetY(),
				bullet->GetRadius(), asteroids[i]->GetRadius()
			))
			{

				cout << "Bullet collided with an asteroid!!\n";
				//may be, add to score here... 
				score += 5;
				//cleanup/destroy the bullet
				delete bullet;
				player->GetBullets()[b] = nullptr;
				player->GetBullets().erase(player->GetBullets().begin() + b);

				//destroy the asteroid
				delete asteroids[i];
				asteroids[i] = nullptr;
				asteroids.erase(asteroids.begin() + i);

				isBreakOutOfLoop = true;

			}
			if (isBreakOutOfLoop)	break;
		}

		if (isBreakOutOfLoop)	break;
	}

	if (isBreakOutOfLoop)
	{
		player->GetBullets().shrink_to_fit();
		asteroids.shrink_to_fit();
	}

}

void GameState::Update()
{
	
	SDL_Event event ;
	
	while (SDL_PollEvent(&event))
	{
		cout << event.type;
	if (event.type == SDL_KEYDOWN)
			{
		
				switch (event.key.keysym.sym)
				{
				case SDLK_SPACE:
					Mix_PlayChannel(-1, fireSound, 0);
					if (player)player->SpawnBullet();
					break;
				case SDLK_w:
					if (!Mix_Playing(15))//if channel 15 is not playing 
						Mix_PlayChannel(15, engineSound, -1); //-1 to loop engine sound
					cIsPressed = true;
					if (player)player->MoveForward();
					//player->UpdatePos();

					break;
				case SDLK_a:
					if (player)player->setAngel(-6.0);
					break;
				case SDLK_d:
					if (player)player->setAngel(+6.0);
					break;
				}

			}
			if (event.type == SDL_KEYUP)
			{
				switch (event.key.keysym.sym)
				{
					//when w key is released 
				case SDLK_w:
					Mix_FadeOutChannel(15, 250);
					cIsPressed = false;
					break;
				}


			}
		}


	if (player)player->Update(cIsPressed);
	for (int i = 0; i < asteroids.size(); i++)
	{
		asteroids[i]->Update();
	}
	if (player) this->CheckCollision();
	//slow down by using SDL_Delay
	SDL_Delay(10); //pause the game loop for 10 milliseconds to slow down the game to a decent speed

}


void GameState::Exit() {}

