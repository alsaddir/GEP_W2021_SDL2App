#include "Player.h"
#include "Game.h"

Player::Player(SDL_Texture *tex, double x, double y)
	: SpriteExAnimated(tex, x - 50, y - 50, 0, 1, 4, 0.1f)
{

	spriteSrcRect = { 0,0,100,100 };
	spriteDestRect = { (int)(m_X - 50),(int) (m_Y-50)  ,100,100 };
}

Player::~Player()
{


}


void Player::Render()
{
	//rendering bullets here

this->SpriteExAnimated::Render(); //invoke the base class's Render()

}


void Player::SetIdle()
{
	spriteSrcRect.y = 0;
	m_iFrame = 0;
	m_iSprite = 0;
}

void Player::Update()
{
	//implement a rotation mechanism

	if (Game::Instance()->KeyDown(SDL_SCANCODE_A))
		angle -= 6.0;
	else if (Game::Instance()->KeyDown(SDL_SCANCODE_D))
		angle += 6.0;


}