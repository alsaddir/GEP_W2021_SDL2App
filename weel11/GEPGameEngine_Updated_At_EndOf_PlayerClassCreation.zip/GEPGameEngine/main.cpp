
#include "SDL.h"
#include "Game.h"

int main(int argc, char* argv[])
{
	//in a non-singleton world, we would have had to create a game object like this
	//and we would have used game->Init() or game->HandleEvents() etc
//	Game *game= new Game();
	//but when using a singleton, we don't create an object explicitly..
	//we instead use 'Instance()' function and access the class members via it

	if (!Game::Instance()->Init("SDL Framework", SDL_WINDOWPOS_CENTERED,
		SDL_WINDOWPOS_CENTERED, 1024, 768, 0))
		return -1; //close the application if initialization fails

	Game::Instance()->InitializeGame();

//	Game::Instance()->InitializeActor(50, 50, 100, 100);

//the path should be the full absolute path of the png file
//in the below case, my pacman.png file is located in the same folder as the main.cpp
	//Game::Instance()->InitializeSpriteActor("walkCycle.png",1, 
	//										8,2,
	//										864,280,  //total spritesheet width and height
	//	                                 0, 0, 108, 140); //destination position & dimension

	//Game::Instance()->InitializeSpriteActor("explosionSprite.png", 0,
	//	5, 4,
	//	910, 728,  //total spritesheet width and height
	//	0, 0, 182, 182); //destination position & dimension

	//first lets define the spaceship
	//Game::Instance()->InitializeSpriteActor("Sprites.png", 2,
	//	4, 3,
	//	256, 192,  //total spritesheet width and height
	//	0, 0, 64, 64,false); //destination position & dimension


	while (Game::Instance()->IsRunning())
	{
		Game::Instance()->HandleEvents();
		Game::Instance()->Update();
		Game::Instance()->Render();
		SDL_Delay(10); //delay of 10 ms after every loop iteration
		

	}
	Game::Instance()->Clean();

	return 0;

}