#pragma once

#include "SpriteEx.h"

class Player : protected SpriteExAnimated
{


public :
	Player(SDL_Texture *tex, double x, double y);
	~Player();
	void Update();
	void Render();
	void SetIdle();


};