#include "Player.h"
#include "Game.h"

Player::Player(SDL_Texture *tex, double x, double y)
	: SpriteExAnimated(tex, x - 50, y - 50, 0, 1, 4, 0.1f)
{

	spriteSrcRect = { 0,0,100,100 };
	spriteDestRect = { (int)(m_X - 50),(int) (m_Y-50)  ,100,100 };
}

Player::~Player()
{


}


void Player::Render()
{
	//rendering bullets here
	for (int i = 0; i < (int)m_vBullets.size(); i++)
		m_vBullets[i]->Render();

this->SpriteExAnimated::Render(); //invoke the base class's Render()

}


void Player::SetIdle()
{
	spriteSrcRect.y = 0;
	m_iFrame = 0;
	m_iSprite = 0;
}

void Player::Update()
{
	//implement a rotation mechanism

	if (Game::Instance()->KeyDown(SDL_SCANCODE_A))
		angle -= 6.0;
	else if (Game::Instance()->KeyDown(SDL_SCANCODE_D))
		angle += 6.0;

	this->UpdateBullets();
}


void Player::UpdateBullets()
{
	for (int i = 0; i < (int)m_vBullets.size(); i++)
	{
		m_vBullets[i]->Update();

		if (m_vBullets[i]->m_X < 0 || m_vBullets[i]->m_X >
			1024 ||
			m_vBullets[i]->m_Y < 0 || m_vBullets[i]->m_Y > 768)
		{
			delete m_vBullets[i];
			m_vBullets[i] = nullptr;
			m_vBullets.erase(m_vBullets.begin() + i);



		}

	}

	m_vBullets.shrink_to_fit();


}

void Player::SpawnBullet()
{
	//converting the player spaceship's angle to deltaX and deltaY 
	float dx = (float)cos((angle - 90) * M_PI / 180);
	float dy = (float)sin((angle - 90) * M_PI / 180);

	m_vBullets.push_back(new Bullet(texture, m_X, m_Y, angle, dx, dy));

}